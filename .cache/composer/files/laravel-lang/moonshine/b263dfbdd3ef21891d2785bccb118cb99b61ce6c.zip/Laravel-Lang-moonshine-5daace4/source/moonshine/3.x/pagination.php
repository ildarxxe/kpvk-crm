<?php

declare(strict_types=1);

return [
    'next'     => 'Next &raquo;',
    'of'       => 'of',
    'previous' => '&laquo; Previous',
    'results'  => 'results',
    'showing'  => 'Showing',
    'to'       => 'to',
];
