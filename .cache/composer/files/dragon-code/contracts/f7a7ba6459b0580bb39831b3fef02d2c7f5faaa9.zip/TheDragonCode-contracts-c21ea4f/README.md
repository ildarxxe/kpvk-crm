# Contracts

<img src="https://preview.dragon-code.pro/TheDragonCode/contracts.svg?brand=php&mode=dark" alt="The Dragon Code's Contracts"/>

A set of contracts for any project.

[![Stable Version][badge_stable]][link_packagist]
[![Total Downloads][badge_downloads]][link_packagist]
[![License][badge_license]][link_license]

## License

This package is licensed under the [MIT License](LICENSE).


[badge_downloads]:      https://img.shields.io/packagist/dt/dragon-code/contracts.svg?style=flat-square

[badge_license]:        https://img.shields.io/packagist/l/dragon-code/contracts.svg?style=flat-square

[badge_stable]:         https://img.shields.io/github/v/release/TheDragonCode/contracts?label=stable&style=flat-square

[link_license]:         LICENSE

[link_packagist]:       https://packagist.org/packages/dragon-code/contracts
