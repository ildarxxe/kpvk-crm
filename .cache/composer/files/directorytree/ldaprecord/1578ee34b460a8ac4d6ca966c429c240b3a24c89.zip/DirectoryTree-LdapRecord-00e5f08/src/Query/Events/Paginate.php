<?php

namespace LdapRecord\Query\Events;

class Paginate extends QueryExecuted
{
    //
}
