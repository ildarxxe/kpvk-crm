<?php

namespace LdapRecord;

class ContainerException extends LdapRecordException
{
    //
}
