<?php

namespace LdapRecord\Models\Events;

class Deleting extends Event
{
    //
}
