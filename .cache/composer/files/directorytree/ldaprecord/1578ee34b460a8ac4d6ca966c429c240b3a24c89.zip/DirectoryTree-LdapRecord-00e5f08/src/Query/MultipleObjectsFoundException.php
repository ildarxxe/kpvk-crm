<?php

namespace LdapRecord\Query;

use LdapRecord\LdapRecordException;

class MultipleObjectsFoundException extends LdapRecordException {}
