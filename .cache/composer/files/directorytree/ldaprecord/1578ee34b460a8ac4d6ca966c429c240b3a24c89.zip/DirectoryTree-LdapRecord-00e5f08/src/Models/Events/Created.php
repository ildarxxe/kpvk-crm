<?php

namespace LdapRecord\Models\Events;

class Created extends Event
{
    //
}
