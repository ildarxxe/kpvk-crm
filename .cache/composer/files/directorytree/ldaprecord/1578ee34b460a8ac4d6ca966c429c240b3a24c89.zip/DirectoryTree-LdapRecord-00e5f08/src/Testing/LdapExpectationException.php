<?php

namespace LdapRecord\Testing;

use Exception;

class LdapExpectationException extends Exception {}
