<?php

namespace LdapRecord\Auth;

use LdapRecord\LdapRecordException;

class PasswordRequiredException extends LdapRecordException
{
    //
}
