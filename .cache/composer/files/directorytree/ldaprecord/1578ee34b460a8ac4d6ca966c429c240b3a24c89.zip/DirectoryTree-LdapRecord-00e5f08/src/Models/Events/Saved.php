<?php

namespace LdapRecord\Models\Events;

class Saved extends Event
{
    //
}
