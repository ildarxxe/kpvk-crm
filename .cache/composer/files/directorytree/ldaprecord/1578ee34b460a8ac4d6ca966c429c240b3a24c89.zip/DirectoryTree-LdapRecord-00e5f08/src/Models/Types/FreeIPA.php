<?php

namespace LdapRecord\Models\Types;

interface FreeIPA extends TypeInterface
{
    //
}
