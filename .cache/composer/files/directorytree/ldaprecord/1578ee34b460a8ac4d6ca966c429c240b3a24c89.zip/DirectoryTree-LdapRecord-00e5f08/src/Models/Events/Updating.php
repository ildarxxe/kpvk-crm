<?php

namespace LdapRecord\Models\Events;

class Updating extends Event
{
    //
}
