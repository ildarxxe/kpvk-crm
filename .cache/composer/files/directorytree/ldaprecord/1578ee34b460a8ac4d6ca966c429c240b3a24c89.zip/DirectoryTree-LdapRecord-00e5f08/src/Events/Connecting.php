<?php

namespace LdapRecord\Events;

class Connecting extends ConnectionEvent
{
    //
}
