<?php

namespace LdapRecord\Models\Events;

class Saving extends Event
{
    //
}
