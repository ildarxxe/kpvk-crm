<?php

namespace LdapRecord\Events;

class Connected extends ConnectionEvent
{
    //
}
