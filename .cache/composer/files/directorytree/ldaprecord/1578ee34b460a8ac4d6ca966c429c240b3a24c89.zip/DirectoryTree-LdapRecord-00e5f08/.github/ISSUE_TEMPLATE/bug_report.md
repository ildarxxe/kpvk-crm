---
name: Bug report
about: Create a report to help improve LdapRecord
assignees: ''

---

<!--
  Please update the below information with your environment.
  Issues filed without the below information will be closed.
-->
**Environment:**
 - LDAP Server Type: [e.g. ActiveDirectory / OpenLDAP / FreeIPA]
 - PHP Version: [e.g. 8.1 / 8.2]

**Describe the bug:**
