---
name: Feature request
about: Suggest an idea for LdapRecord
title: "[Feature]"
labels: enhancement
assignees: ''

---

**Describe the feature you'd like:**
