<?php

namespace LdapRecord\Laravel\Auth;

use LdapRecord\Laravel\ImportableFromLdap;

trait AuthenticatesWithLdap
{
    use ImportableFromLdap;
}
