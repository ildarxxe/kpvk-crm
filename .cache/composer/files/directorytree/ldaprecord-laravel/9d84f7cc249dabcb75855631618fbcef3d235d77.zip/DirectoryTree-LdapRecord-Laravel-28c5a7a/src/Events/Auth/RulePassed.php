<?php

namespace LdapRecord\Laravel\Events\Auth;

class RulePassed extends RuleEvent
{
    //
}
