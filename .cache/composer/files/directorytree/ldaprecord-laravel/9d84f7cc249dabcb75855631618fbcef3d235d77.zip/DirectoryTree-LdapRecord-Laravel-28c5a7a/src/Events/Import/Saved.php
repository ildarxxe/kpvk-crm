<?php

namespace LdapRecord\Laravel\Events\Import;

class Saved extends Event
{
    //
}
