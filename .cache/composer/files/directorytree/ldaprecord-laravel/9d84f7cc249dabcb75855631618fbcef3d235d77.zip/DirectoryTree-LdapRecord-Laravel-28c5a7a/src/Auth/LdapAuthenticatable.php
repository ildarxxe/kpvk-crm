<?php

namespace LdapRecord\Laravel\Auth;

use LdapRecord\Laravel\LdapImportable;

interface LdapAuthenticatable extends LdapImportable
{
    //
}
