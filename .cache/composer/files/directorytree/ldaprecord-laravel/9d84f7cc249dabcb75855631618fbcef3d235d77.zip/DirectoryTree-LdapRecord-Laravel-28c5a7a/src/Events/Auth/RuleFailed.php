<?php

namespace LdapRecord\Laravel\Events\Auth;

class RuleFailed extends RuleEvent
{
    //
}
